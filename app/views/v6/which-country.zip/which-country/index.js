module.exports = require('./lib/which-country.js');
