var tree = require('./lib/new-tree.js')();

console.log(JSON.stringify(tree.toJSON()));
